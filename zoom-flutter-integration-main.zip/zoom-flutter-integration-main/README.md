Zoom Meeting Join — Flutter Integration
Professional Flutter sample that demonstrates how to join a Zoom meeting from inside a Flutter app using the Zoom Meeting SDK. This repository contains minimal wiring to initialize the Meeting SDK and join as a participant for development testing.

Goals
Let users join a Zoom meeting from inside the app (no external browser required).
Demonstrate a secure development workflow: generate short-lived Meeting SDK JWTs for testing and recommend server-side token minting for production.
Repository structure
lib/ — Flutter source (integration points: zoom_bridge.dart, zoom_join_screen.dart, zoom_meeting_configuration.dart).
android/, ios/ — platform-specific integration and native SDK configuration.
Prerequisites
Flutter SDK (https://flutter.dev).
Platform toolchains for your target platforms (Android Studio for Android, Xcode for iOS).
A Zoom developer account and a Meeting SDK app created in the Zoom App Marketplace.
Quick start
Clone the repository:

git clone https://github.com/Yusuf92002/zoom-join-meeting-flutter-integration.git cd zoom-join-meeting-flutter-integration

Install dependencies:

flutter pub get

Configure your credentials and token generation (see "Configuration" below).

Run the app on a device or emulator:

flutter run

Configuration
In the Zoom App Marketplace create a Meeting SDK app or an appropriate app type and obtain the AppKey (Client ID) and App Secret (Client Secret).

For quick development testing, you can generate a Participant Meeting SDK JWT using Zoom's Test SDK JWT generator (see "Generating a Participant JWT" below). For production, use a backend to mint tokens.

Supply credentials to the app during development. Example (PowerShell):

$env:ZOOM_MEETING_SDK_KEY = "<YOUR_APP_KEY>"
$env:ZOOM_MEETING_SDK_SECRET = "<YOUR_APP_SECRET>"
# Or, if you already generated a participant JWT for local testing:
$env:MEETING_PARTICIPANT_JWT = "<GENERATED_PARTICIPANT_JWT>"
The Flutter code reads the configured token or mints a join request using the SDK initialization. See lib/zoom_bridge.dart and lib/zoom_join_screen.dart for the join flow and where to plug in the JWT.
Generating a Participant JWT for development (based on included screenshots)
Follow these steps to create a short-lived Participant JWT for local testing:

Create an app in Zoom App Marketplace (choose the app type that exposes Meeting SDK credentials).
The screenshot below demonstrates creating a General/Meeting SDK app:<img width="1800" height="855" alt="494281119-1188622a-efc7-4ab9-817f-e10f6b6e6c10" src="https://github.com/user-attachments/assets/b731514f-4aed-4ce7-b823-c406577188ac" />
In the app configuration enable the Meeting SDK Embed options and note the platform SDK versions if you need native SDKs:

<img width="1820" height="855" alt="494281266-04e3a295-c338-4b67-953e-01553a11aca8" src="https://github.com/user-attachments/assets/48e6a7cc-6f33-40bf-a3b2-c043f213a392" />
<img width="1791" height="864" alt="494281634-8efc4a9d-b3d1-4957-bb4a-e743e58b48c1" src="https://github.com/user-attachments/assets/fd01298d-5346-4ab1-9e8c-e5ed845614c7" />
Open the Meeting SDK docs and use the "Test SDK JWT generator" tab. Enter:

Meeting SDK AppKey (Client ID)
Meeting SDK Secret (Client Secret)
Meeting Number for the meeting you want to join
Role Type = Participant
Generate the JWT and copy the token:<img width="1920" height="862" alt="494281730-d291bcc5-f147-4428-a65b-5c2cccff502f" src="https://github.com/user-attachments/assets/0f9256a8-fe39-4297-9233-bbd5e795223a" />
Use that token for local development by exporting it as an environment variable, or paste it into the debug configuration. The app can then use the token to join as a Participant.

Important: the Test SDK JWT generator is for development only. Tokens are short lived and should not be used in production.

Local SDK files and gitignore
If you download Zoom Meeting SDK binaries for Android, iOS or other platforms, place them locally and do not commit them to the repository. Typical locations used by this project:

Android native SDKs / libraries: android/app/libs/
iOS native SDKs: ios/ZoomSDK/ or ios/Pods/ZoomSDK/ when using CocoaPods
Alternative local folder: top-level ZoomSDK/ or libs/ for manual placement
This repository's .gitignore already excludes these folders so you can keep the SDKs locally and out of version control. Do not add SDK binaries or secrets to commits — add them to your local .gitignore or the project's .gitignore if you change your folder layout.

Security recommendations
Never commit App Secrets, Client Secrets, or JWTs into source control.
For production, implement a small backend service that holds the App Secret and mints short-lived JWTs on demand. The client requests a token from your backend over TLS and then uses it to initialize/join the meeting.
Keep JWT lifetimes short and scope tokens to the minimum privileges needed (Participant vs Host).
Use HTTPS/TLS for all connections between client and backend.
Rotate secrets regularly and follow Zoom's security checklists when publishing apps.
Troubleshooting
SDK initialization errors often indicate invalid credentials or missing native SDK artifacts; check device logs.
Authentication/join failures: verify the JWT was generated with the correct AppKey and Secret and the meeting number and role are correct.
References
Zoom Meeting SDK docs: https://developer.zoom.us/docs/meetings/overview/
Zoom App Marketplace: https://marketplace.zoom.us/
Contributing
Contributions are welcome. Open an issue or a pull request. Do not add secrets to commits.
License
MIT
Credits
Demo prepared to illustrate embedding Zoom meeting join functionality in a Flutter application while following secure practices for development and production.
